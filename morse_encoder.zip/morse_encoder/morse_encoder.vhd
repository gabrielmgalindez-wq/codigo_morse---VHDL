library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity morse_encoder is
    Port (
        CLOCK_50 : in  STD_LOGIC;               -- Reloj del sistema (50 MHz)
        KEY      : in  STD_LOGIC_VECTOR(1 downto 0); -- KEY(0): Reset asincrónico, KEY(1): Start
        SW       : in  STD_LOGIC_VECTOR(2 downto 0); -- Seleccion de letra A-H
        LEDR     : out STD_LOGIC_VECTOR(0 downto 0)  -- LEDR(0): Salida del codigo Morse
    );
end morse_encoder;

architecture Behavioral of morse_encoder is

    -- Tipos de la maquina de estados
    type state_type is (IDLE, LOAD, TRANSMIT, PAUSE, PAUSE_LETTER);
    signal state_reg, state_next : state_type;

    -- Senales del contador de 0.5s (25,000,000 ciclos a 50MHz)
    constant HALF_SEC_MAX : integer := 25000000 - 1;
    signal half_sec_counter : integer range 0 to HALF_SEC_MAX := 0;
    signal half_sec_pulse : std_logic := '0';

    -- Registros para la secuencia Morse
    signal shift_reg   : std_logic_vector(3 downto 0) := (others => '0');
    signal bit_count   : integer range 0 to 4 := 0;
    signal timer_pulses: integer range 0 to 3 := 0; -- Duracion en pulsos de 0.5s
    signal pulse_count : integer range 0 to 3 := 0;

    signal reset_n : std_logic;
    signal start_n : std_logic;

begin
    reset_n <= KEY(0); -- Asynchronous Reset active low
    start_n <= KEY(1); -- Start transmission active low

    -- 1. Generator de Pulsos de 0.5 Segundos
    process(CLOCK_50, reset_n)
    begin
        if reset_n = '0' then
            half_sec_counter <= 0;
            half_sec_pulse <= '0';
        elsif rising_edge(CLOCK_50) then
            if half_sec_counter = HALF_SEC_MAX then
                half_sec_counter <= 0;
                half_sec_pulse <= '1';
            else
                half_sec_counter <= half_sec_counter + 1;
                half_sec_pulse <= '0';
            end if;
        end if;
    end process;

    -- 2. Transicion de Estados y Logica Secuencial
    process(CLOCK_50, reset_n)
    begin
        if reset_n = '0' then
            state_reg   <= IDLE;
            shift_reg   <= (others => '0');
            bit_count   <= 0;
            pulse_count <= 0;
        elsif rising_edge(CLOCK_50) then
            state_reg <= state_next;

            case state_reg is
                when IDLE =>
                    pulse_count <= 0;

                when LOAD =>
                    -- Seleccion de la letra (0=Punto/0.5s, 1=Raya/1.5s)
                    case SW is
                        when "000" => shift_reg <= "0100"; bit_count <= 2; -- A: .-
                        when "001" => shift_reg <= "1000"; bit_count <= 4; -- B: -...[cite: 6]
                        when "010" => shift_reg <= "1010"; bit_count <= 4; -- C: -.-.[cite: 6]
                        when "011" => shift_reg <= "1000"; bit_count <= 3; -- D: -..[cite: 6]
                        when "100" => shift_reg <= "0000"; bit_count <= 1; -- E: .[cite: 6]
                        when "101" => shift_reg <= "0010"; bit_count <= 4; -- F: ..-.[cite: 6]
                        when "110" => shift_reg <= "1100"; bit_count <= 3; -- G: --.[cite: 6]
                        when "111" => shift_reg <= "0000"; bit_count <= 4; -- H: ....[cite: 6]
                        when others => null;
                    end case;

                when TRANSMIT =>
                    if half_sec_pulse = '1' then
                        pulse_count <= pulse_count + 1;
                    end if;

                when PAUSE =>
                    if half_sec_pulse = '1' then
                        pulse_count <= 0;
                        shift_reg <= shift_reg(2 downto 0) & '0'; -- Desplazamiento
                        bit_count <= bit_count - 1;
                    end if;

                when PAUSE_LETTER =>
                    if half_sec_pulse = '1' then
                        pulse_count <= 0;
                    end if;
            end case;
        end if;
    end process;

    -- 3. Logica del Proximo Estado
    process(state_reg, start_n, half_sec_pulse, pulse_count, shift_reg, bit_count)
    begin
        state_next <= state_reg;

        case state_reg is
            when IDLE =>
                if start_n = '0' then
                    state_next <= LOAD;
                end if;

            when LOAD =>
                state_next <= TRANSMIT;

            when TRANSMIT =>
                -- Punto: 1 pulso (0.5s), Raya: 3 pulsos (1.5s)[cite: 6]
                if (shift_reg(3) = '0' and pulse_count >= 1 and half_sec_pulse = '1') or
                   (shift_reg(3) = '1' and pulse_count >= 3 and half_sec_pulse = '1') then
                    state_next <= PAUSE;
                end if;

            when PAUSE =>
                if half_sec_pulse = '1' then
                    if bit_count - 1 = 0 then
                        state_next <= PAUSE_LETTER;
                    else
                        state_next <= TRANSMIT;
                    end if;
                end if;

            when PAUSE_LETTER =>
                if half_sec_pulse = '1' then
                    state_next <= IDLE;
                end if;

            when others =>
                state_next <= IDLE;
        end case;
    end process;

    -- Salida LEDR0
    LEDR(0) <= '1' when (state_reg = TRANSMIT) else '0';

end Behavioral;